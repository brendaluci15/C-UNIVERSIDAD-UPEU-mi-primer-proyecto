import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {TallerService} from "../../../../providers/services/taller.service";


@Component({
  selector: 'app-taller-modal',
  templateUrl: './taller-modal.component.html',
  styleUrls: ['./taller-modal.component.css']
})
export class TallerModalComponent implements OnInit {
  @Input() title: any;
  @Input() tId: any;
  @Input() item: any;
  isUpdate: boolean = false;

  formTaller: FormGroup;
  constructor(public activeModal: NgbActiveModal,
              private formBuilder: FormBuilder,
              private tallerService: TallerService) {}

  ngOnInit(): void {
    this.formInit();
    if(this.item) {
      this.updateData();
    }
  }

  private formInit(): void {
    const controls = {
      tTema: ['', [Validators.required]],
      tFecha_Inicio: ['', [Validators.required]],
      tFecha_Fin: ['', [Validators.required]],
      tHora: ['', [Validators.required]],
      tLugar: ['', [Validators.required]],

    };
    this.formTaller = this.formBuilder.group(controls);
  }

  save(): void {
    this.tallerService.add$(this.formTaller.value).subscribe(response => {
      if(response.success){
        this.activeModal.close({success: true, message: response.message});
      }
    });
  }

  update(): void {
    this.tallerService.update$(this.tId, this.formTaller.value).subscribe(response => {
      if(response.success) {
        this.activeModal.close({success: true, message: response.message});
      }
    });
  }

  private updateData(): void {
    const data = this.item;
    this.formTaller.patchValue(data);
  }
}
