import { Component, OnInit } from '@angular/core';
import {TallerService} from "../../providers/services/taller.service";

@Component({
  selector: 'app-taller',
  templateUrl: './talleres.component.html',
  styleUrls: ['./talleres.component.css']
})
export class TalleresComponent implements OnInit {
 taller: any = [];

  constructor(private tallerService: TallerService) { }

  ngOnInit(): void {
    this.getTalleres();

  }
  getTalleres(): void {
    this.tallerService.getAll$().subscribe( response => {
      this.taller = response.data || [];

    });
  }
}
