import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {PersonaService} from "../../../../providers/services/persona.service";

@Component({
  selector: 'app-personas-modal',
  templateUrl: './personas-modal.component.html',
  styleUrls: ['./personas-modal.component.css']
})
export class PersonasModalComponent implements OnInit {
  @Input() title:any;
  @Input() pId:any;
  @Input() item:any;
  isUpdate:boolean = false;

  formPersonas:FormGroup
  formGroup: any;
  constructor(public activeModal: NgbActiveModal,
              private formBuilder: FormBuilder,
              private personaService:PersonaService) { }

  ngOnInit(): void {
    this.formInit();
    if (this.item){
      this.updateData();
    }
  }
private formInit(): void {
  const controls = {
    pnombre: ['',[Validators.required]],
    papellidoPaterno:['',[Validators.required]],
    papellidoMaterno:['',[Validators.required]],
    pteléfono: ['',[Validators.required]],
    pdni: ['',[Validators.required]],
    tipoPersona: ['',[Validators.required]],

  };
  this.formPersonas = this.formBuilder.group(controls);
}
save():void {
  /*(data: any):void{
      const save:any ={
    papellidoMaterno: data.papellidoMaterno,
      papellidoPaterno:data.papellidoPaterno,
      pdni:data.pdni,
      pnombre:data.pnombre,
      pteléfono:data.pteléfono,
      tipoPersona:{
        tpId:data.tpId*/



    this.personaService.add$(this.formPersonas.value).subscribe(response=>{
      if(response.success){
        this.activeModal.close({success:true,message:response.message});
      }
    });
}

  update(): void {
    this.personaService.update$(this.pId, this.formPersonas.value).subscribe(response => {
      if(response.success) {
        this.activeModal.close({success: true, message: response.message});
      }
    });
}
  private updateData():void{
    const data=this.item;
  this.formPersonas.patchValue(data);
//this.formPersona.patchValue(data)

      // pNombre:data.pName,
      // pDNI:data.pDNI

    //console.log(this.formPersona.value)


  }
}
