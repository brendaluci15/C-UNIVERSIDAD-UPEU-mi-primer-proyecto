import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PersonasComponent } from './personas.component';
import {PersonasRoutingModule} from "./personas-routing.module";
import {PersonaService} from "../../../providers/services/persona.service";
import { PersonasModalComponent } from './personas-modal/personas-modal.component';
import {ReactiveFormsModule} from "@angular/forms";

@NgModule({
  declarations: [
    PersonasComponent,
    PersonasModalComponent
  ],
    imports: [
        CommonModule,
        PersonasRoutingModule,
        ReactiveFormsModule
    ],
  providers: [
    PersonaService
  ]
})
export class PersonasModule { }
