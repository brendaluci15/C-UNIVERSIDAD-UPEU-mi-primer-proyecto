import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialesComponent } from './materiales.component';
import {MaterialesRoutingModule} from "./materiales-routing.module";
import {MaterialesService} from "../../../providers/services/materiales.service";
import {ReactiveFormsModule} from "@angular/forms";
import {MaterialesModalComponent} from "./materiales-modal/materiales-modal.component";




@NgModule({
  declarations: [
    MaterialesComponent,
    MaterialesModalComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MaterialesRoutingModule
  ],
  providers: [
    MaterialesService
  ]
})
export class MaterialesModule { }
