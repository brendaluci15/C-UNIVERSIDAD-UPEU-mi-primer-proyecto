import {Component, Input, OnInit} from '@angular/core';
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {MaterialesService} from "../../../../providers/services/materiales.service";


@Component({
  selector: 'app-materiales-modal',
  templateUrl: './materiales-modal.component.html',
  styleUrls: ['./materiales-modal.component.css']
})
export class MaterialesModalComponent implements OnInit {
  @Input() title: any;
  @Input() mId: any;
  @Input() item: any;
  isUpdate: boolean ;

  formMateriales: FormGroup;
  constructor(public activeModal: NgbActiveModal,
              private formBuilder: FormBuilder,
              private materialesService: MaterialesService) {}

  ngOnInit(): void {
    this.formInit();

    this.isUpdate =false;
    if(this.item) {
      this.updateData();
    }
  }

  private formInit(): void {
    const controls = {
      mnombre: ['', [Validators.required]],
      mnescripcion: ['', [Validators.required]],
    };
    this.formMateriales = this.formBuilder.group(controls);
  }

  save(): void {
    this.materialesService.add$(this.formMateriales.value).subscribe(response => {
      if(response.success){
        this.activeModal.close({success: true, message: response.message});
      }
    });
  }

  update(): void {
    this.materialesService.update$(this.mId, this.formMateriales.value).subscribe(response => {
      if(response.success) {
        this.activeModal.close({success: true, message: response.message});
      }
    });
  }

   updateData(): void {
    const data = this.item;
    this.formMateriales.patchValue(data);
  }
}
