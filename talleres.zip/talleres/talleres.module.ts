import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TalleresComponent } from './talleres.component';
import {TalleresRoutingModule} from "./talleres-routing.module";
import {TallerService} from "../../providers/services/taller.service";



@NgModule({
  declarations: [
    TalleresComponent
  ],
  imports: [
    CommonModule,
    TalleresRoutingModule
  ],
  providers: [
    TallerService
  ]
})
export class TalleresModule { }
