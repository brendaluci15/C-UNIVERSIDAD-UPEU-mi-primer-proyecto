/*import { Injectable } from '@angular/core';
import {EntityDataService} from "../utils/entity-data.service";
import {END_POINTS} from "../utils/end-points";
import {IResponse} from "../utils/response";

@Injectable({
  providedIn: 'root'
})
export class AsistenciasService extends EntityDataService<IResponse>{

  constructor(protected override httpClient:httpClient) {
    super(httpClient, END_POINTS.api + END_POINTS.reportes.asistencias);
  }
}*/
